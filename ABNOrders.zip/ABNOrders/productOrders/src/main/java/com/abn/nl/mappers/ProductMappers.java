package com.abn.nl.mappers;

import com.abn.nl.Product;
import com.abn.nl.ProductDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

import java.util.List;
import java.util.Set;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface ProductMappers {
    ProductMappers INSTANCE = Mappers.getMapper(ProductMappers.class);
    @Mapping(target = "articleName",source = "name")
    Set<ProductDTO> getProducts (Set<Product> products);
}
