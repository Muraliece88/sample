package com.abn.nl.service;

import com.abn.nl.ProductDTO;

import java.util.List;
import java.util.Set;

public interface ProductService {

    Set<ProductDTO> getProducts(List<String> productNames);
}
