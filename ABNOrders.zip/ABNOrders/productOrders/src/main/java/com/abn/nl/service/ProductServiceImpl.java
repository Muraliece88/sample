package com.abn.nl.service;

import com.abn.nl.mappers.ProductMappers;
import com.abn.nl.ProductDTO;
import com.abn.nl.ProductsRepo;
import lombok.extern.slf4j.Slf4j;
import org.mapstruct.factory.Mappers;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

@Service
@Slf4j
public class ProductServiceImpl implements ProductService{
    private final ProductsRepo productsRepo;
    private final ProductMappers mappers = Mappers.getMapper(ProductMappers.class);

    public ProductServiceImpl(ProductsRepo productsRepo) {
        this.productsRepo = productsRepo;
    }

    @Override
    public Set<ProductDTO> getProducts(List<String> productNames) {

        return mappers.INSTANCE.getProducts(productsRepo.findProductByNameIn(productNames));
    }
}
