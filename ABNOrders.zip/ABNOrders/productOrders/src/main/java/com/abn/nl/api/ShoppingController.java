package com.abn.nl.api;

import com.abn.nl.service.ProductServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;

@Slf4j
@RestController
@RequestMapping("/api/v1/products")
public class ShoppingController {
    private final String path="/fetchProducts";
    private final ProductServiceImpl serviceImpl;

    public ShoppingController(ProductServiceImpl serviceImpl) {
        this.serviceImpl = serviceImpl;
    }

    @GetMapping(path = path
            ,produces = MediaType.APPLICATION_JSON_VALUE)
    private ResponseEntity<?> getProducts(@RequestParam(required = false) String products)
    {


        return ResponseEntity.ok(serviceImpl.getProducts(Arrays.asList(products.split(","))));
    }

}
