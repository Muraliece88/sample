package com.abn.nl;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

@Repository
public interface ProductsRepo extends JpaRepository<Product, Long> {
    Set<Product> findProductByNameIn(List<String> name);
}
