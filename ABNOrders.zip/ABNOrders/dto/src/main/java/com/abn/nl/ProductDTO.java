package com.abn.nl;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class ProductDTO {
    private String articleName;
    private String brand;
    private String quantity;
    private String currency;
    private BigDecimal price;
    private String seller;

}
